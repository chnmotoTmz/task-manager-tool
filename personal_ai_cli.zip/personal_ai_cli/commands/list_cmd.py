# -*- coding: utf-8 -*-
import typer
import pandas as pd
from rich.console import Console
from rich.table import Table

# Import the shared DataManager instance from main.py (or a shared context module)
# To avoid circular imports or complex context passing for now, 
# we might need to adjust how DataManager is shared. 
# A simple approach for now is to re-instantiate, but this is not ideal.
# Let's assume main.py will pass the instance or we use a shared module later.
# For now, re-instantiate for isolated testing/development of this module.
from data_manager import DataManager

app = typer.Typer()
console = Console()
# This creates a new instance; ideally, share the one from main.py
# This should be refactored later to use a single instance.
data_manager = DataManager(base_dir="/home/ubuntu/personal_ai_cli/") 

@app.command("show", help="タスクを一覧表示します。ステータスや優先度でフィルタリング、期日や優先度でソートできます。")
def list_tasks(
    status: str = typer.Option(None, "--status", "-s", help="表示するタスクのステータス (例: TODO, 進行中)"),
    priority: str = typer.Option(None, "--priority", "-p", help="表示するタスクの優先度 (例: 高, 中, 低)"),
    sort_by: str = typer.Option("期日", "--sort", "-o", help="ソート順 (\"期日\" または \"優先度\")"),
    limit: int = typer.Option(20, "--limit", "-n", help="表示する最大タスク数")
):
    """登録されているタスクを一覧表示します。"""
    try:
        # Ensure data is loaded (important if re-instantiating)
        if data_manager.issues_df is None:
            data_manager.load_data()
            if data_manager.issues_df is None:
                 console.print("[bold red]エラー: issues.csv の読み込みに失敗しました。[/bold red]")
                 return
                 
        tasks_df = data_manager.get_tasks(status=status, priority=priority, sort_by=sort_by)
        
        if tasks_df.empty:
            console.print("[yellow]条件に合うタスクは見つかりませんでした。[/yellow]")
            return

        # Limit the number of tasks shown
        tasks_df = tasks_df.head(limit)

        table = Table(title=f"タスク一覧 ({status or '全ステータス'}, {priority or '全優先度'}, {sort_by}順, 最大{limit}件)", show_header=True, header_style="bold magenta")
        table.add_column("#", style="dim", width=6)
        table.add_column("題名", style="", min_width=30)
        table.add_column("ステータス", style="", width=10)
        table.add_column("優先度", style="", width=8)
        table.add_column("期日", style="", width=12)
        table.add_column("進捗%", style="cyan", width=6, justify="right")
        table.add_column("作業時間", style="green", width=8, justify="right")
        table.add_column("予定工数", style="blue", width=8, justify="right")

        for index, task in tasks_df.iterrows():
            # Format date, handle NaT
            due_date_str = task["期日"].strftime("%Y-%m-%d") if pd.notna(task["期日"]) else "-"
            # Format numbers, handle NaN/None
            # Corrected lines:
            progress_val = task.get("進捗率", 0)
            progress = f"{int(progress_val):>3d}%" if pd.notna(progress_val) else "-"
            spent_time_val = task.get("合計作業時間", 0.0)
            spent_time = f"{spent_time_val:.2f}" if pd.notna(spent_time_val) else "-"
            planned_time_val = task.get("合計予定工数", 0.0)
            planned_time = f"{planned_time_val:.2f}" if pd.notna(planned_time_val) else "-"
            
            # Determine row style based on priority or status
            row_style = ""
            priority_val = task.get("優先度", "")
            if priority_val == "高":
                row_style = "bold red"
            elif priority_val == "低":
                row_style = "dim"
            elif task.get("ステータス", "") == "完了":
                 row_style = "dim green"

            table.add_row(
                str(task["#"]),
                task["題名"],
                task["ステータス"],
                priority_val,
                due_date_str,
                progress,
                spent_time,
                planned_time,
                style=row_style
            )

        console.print(table)

    except Exception as e:
        console.print(f"[bold red]エラーが発生しました: {e}[/bold red]")

# This allows running `python -m commands.list_cmd` for testing if needed
if __name__ == "__main__":
    # Need to adjust imports if running directly
    # Example: Add project root to sys.path or run from project root
    # import sys
    # sys.path.append("..") # Add parent directory if running from commands/
    # from data_manager import DataManager
    app()

