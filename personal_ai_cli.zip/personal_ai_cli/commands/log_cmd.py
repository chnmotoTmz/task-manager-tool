# -*- coding: utf-8 -*-
import typer
from rich.console import Console
import pandas as pd # Import pandas for pd.notna

# Assuming DataManager is accessible. Refactor later for proper instance sharing.
from data_manager import DataManager

app = typer.Typer()
console = Console()
data_manager = DataManager(base_dir="/home/ubuntu/personal_ai_cli/")

@app.command("add", help="指定されたタスクIDに作業時間を記録します。")
def add_log(
    task_id: int = typer.Argument(..., help="作業時間を記録するタスクのID"),
    hours: float = typer.Argument(..., help="記録する作業時間 (例: 1.5)"),
    comment: str = typer.Option("", "--comment", "-c", help="作業内容に関するコメント")
):
    """指定されたタスクIDに対して作業時間を記録し、関連する課題情報を更新します。"""
    try:
        # Ensure data is loaded
        if data_manager.issues_df is None or data_manager.timelog_df is None:
            data_manager.load_data()
            if data_manager.issues_df is None or data_manager.timelog_df is None:
                 console.print("[bold red]エラー: CSVファイルの読み込みに失敗しました。[/bold red]")
                 return
                 
        success = data_manager.add_log_entry(task_id=task_id, hours=hours, comment=comment)
        
        if success:
            console.print(f"[bold green]タスク {task_id} に {hours} 時間の作業ログを追加しました。[/bold green]")
            # Optionally show updated task details
            updated_task = data_manager.get_task_by_id(task_id)
            if updated_task:
                # Corrected f-strings
                title = updated_task.get("題名", "N/A")
                total_spent = updated_task.get("合計作業時間", 0.0)
                progress = updated_task.get("進捗率", 0)
                console.print(f"  題名: {title}")
                console.print(f"  更新後の合計作業時間: {total_spent:.2f}")
                console.print(f"  更新後の進捗率: {int(progress)}%")
        else:
            # Error message is printed within add_log_entry if task ID not found
            # Add a generic failure message here if add_log_entry returns False for other reasons
            if not data_manager.get_task_by_id(task_id):
                 pass # Error already printed by DataManager
            else:
                 console.print(f"[bold red]エラー: タスク {task_id} へのログ記録に失敗しました。[/bold red]")
            
    except Exception as e:
        console.print(f"[bold red]ログ記録中にエラーが発生しました: {e}[/bold red]")

# Allow running `python -m commands.log_cmd` for testing
if __name__ == "__main__":
    app()

