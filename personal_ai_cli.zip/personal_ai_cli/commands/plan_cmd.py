# -*- coding: utf-8 -*-
import typer
import pandas as pd
from rich.console import Console
from rich.table import Table
import datetime

# Assuming DataManager is accessible. Refactor later for proper instance sharing.
from data_manager import DataManager

app = typer.Typer()
console = Console()
data_manager = DataManager(base_dir="/home/ubuntu/personal_ai_cli/")

@app.command("suggest", help="今後の作業計画（どのタスクに注力すべきか）を提案します。")
def suggest_plan(
    days: int = typer.Option(7, "--days", "-d", help="計画を提案する日数"),
    max_tasks: int = typer.Option(10, "--max-tasks", "-n", help="提案に含める最大タスク数")
):
    """優先度と期日に基づいて、今後取り組むべきタスクを提案します。"""
    try:
        # Ensure data is loaded
        if data_manager.issues_df is None:
            data_manager.load_data()
            if data_manager.issues_df is None:
                 console.print("[bold red]エラー: issues.csv の読み込みに失敗しました。[/bold red]")
                 return

        today = pd.Timestamp.now().normalize()
        target_date = today + pd.Timedelta(days=days)
        
        # Corrected f-string
        today_str = today.strftime("%Y-%m-%d")
        target_date_str = target_date.strftime("%Y-%m-%d")
        console.print(f"[bold blue]--- 今後 {days} 日間 ({today_str} - {target_date_str}) の推奨タスク ---[/bold blue]")

        # Filter for active tasks (TODO or 進行中)
        active_tasks = data_manager.issues_df[
            data_manager.issues_df["ステータス"].isin(["TODO", "進行中"])
        ].copy() # Use copy to avoid SettingWithCopyWarning

        if active_tasks.empty:
            console.print("[yellow]現在アクティブなタスクはありません。[/yellow]")
            return

        # Calculate priority score (example: higher score for higher priority and closer due date)
        # Lower number means higher priority
        priority_map = {"高": 0, "中": 1, "低": 2}
        active_tasks["priority_score"] = active_tasks["優先度"].map(priority_map).fillna(1) # Default to medium if priority is missing

        # Calculate days until due date (negative if past due)
        active_tasks["days_until_due"] = (active_tasks["期日"] - today).dt.days
        # Handle NaT in due dates - give them lower priority than tasks with due dates
        active_tasks["days_until_due"] = active_tasks["days_until_due"].fillna(9999) 

        # Sort tasks: 1. Priority (High first), 2. Due Date (Closer first)
        sorted_tasks = active_tasks.sort_values(by=["priority_score", "days_until_due"], ascending=[True, True])

        # Select top N tasks for the plan
        plan_tasks = sorted_tasks.head(max_tasks)

        if plan_tasks.empty:
             console.print("[yellow]計画に含めるべき優先タスクは見つかりませんでした。[/yellow]")
             return

        table = Table(title=f"推奨タスク (上位 {len(plan_tasks)} 件)", show_header=True, header_style="bold magenta")
        table.add_column("#", style="dim", width=6)
        table.add_column("題名", style="", min_width=30)
        table.add_column("優先度", style="", width=8)
        table.add_column("期日", style="", width=12)
        table.add_column("ステータス", style="", width=10)
        table.add_column("残工数", style="blue", width=8, justify="right")

        for index, task in plan_tasks.iterrows():
            due_date_str = task["期日"].strftime("%Y-%m-%d") if pd.notna(task["期日"]) else "-"
            remaining_hours_val = task.get("残工数", 0.0)
            remaining_hours = f"{remaining_hours_val:.2f}" if pd.notna(remaining_hours_val) else "-"
            
            row_style = ""
            priority_val = task.get("優先度", "")
            if priority_val == "高":
                row_style = "bold red"
            elif priority_val == "低":
                row_style = "dim"
            
            # Highlight overdue tasks
            if pd.notna(task["期日"]) and task["期日"] < today:
                 due_date_str = f"[bold yellow]{due_date_str} (期限切れ)[/bold yellow]"
                 if not row_style: row_style = "yellow"
                 
            table.add_row(
                str(task["#"]),
                task["題名"],
                priority_val,
                due_date_str,
                task["ステータス"],
                remaining_hours,
                style=row_style
            )

        console.print(table)
        console.print(f"\n[italic]上記は優先度と期日に基づく提案です。残工数も考慮して計画を調整してください。[/italic]")

    except Exception as e:
        console.print(f"[bold red]計画提案中にエラーが発生しました: {e}[/bold red]")

# Allow running `python -m commands.plan_cmd` for testing
if __name__ == "__main__":
    app()

