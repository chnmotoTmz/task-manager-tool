# -*- coding: utf-8 -*-
import typer
import pandas as pd
from rich.console import Console
from rich.table import Table
import datetime

# Assuming DataManager is accessible. Refactor later for proper instance sharing.
from data_manager import DataManager

app = typer.Typer()
console = Console()
data_manager = DataManager(base_dir="/home/ubuntu/personal_ai_cli/")

@app.command("summary", help="指定された期間の作業概要や進捗を表示します。")
def report_summary(
    period: str = typer.Option("week", "--period", "-p", help="集計期間 ('week' または 'month')")
):
    """作業時間やタスクの進捗状況に関するサマリーレポートを表示します。"""
    try:
        # Ensure data is loaded
        if data_manager.issues_df is None or data_manager.timelog_df is None:
            data_manager.load_data()
            if data_manager.issues_df is None or data_manager.timelog_df is None:
                 console.print("[bold red]エラー: CSVファイルの読み込みに失敗しました。[/bold red]")
                 return

        # Determine date range for filtering
        today = pd.Timestamp.now().normalize() # Get date part only
        if period.lower() == "week":
            start_date = today - pd.Timedelta(days=today.dayofweek) # Start of current week (Monday)
            end_date = start_date + pd.Timedelta(days=6) # End of current week (Sunday)
            title_period = "今週"
        elif period.lower() == "month":
            start_date = today.replace(day=1) # Start of current month
            end_date = (start_date + pd.DateOffset(months=1)) - pd.Timedelta(days=1) # End of current month
            title_period = "今月"
        else:
            console.print(f"[bold red]エラー: 無効な期間が指定されました: {period}。'week' または 'month' を使用してください。[/bold red]")
            return
        
        # Corrected f-string
        start_date_str = start_date.strftime('%Y-%m-%d')
        end_date_str = end_date.strftime('%Y-%m-%d')
        console.print(f"[bold blue]--- {title_period}の作業サマリー ({start_date_str} - {end_date_str}) ---[/bold blue]")

        # 1. Total hours logged in the period
        period_logs = data_manager.timelog_df[
            (data_manager.timelog_df["日付"] >= start_date) & 
            (data_manager.timelog_df["日付"] <= end_date)
        ]
        total_hours_period = period_logs["時間"].sum()
        console.print(f"[green]✓ {title_period}の合計作業時間:[/green] {total_hours_period:.2f} 時間")

        # 2. Summary of tasks worked on (Top N by hours)
        if not period_logs.empty:
            # Extract task ID from the 'チケット' column (e.g., "TASK #165")
            # Use .copy() to avoid SettingWithCopyWarning
            period_logs = period_logs.copy()
            period_logs["task_id_str"] = period_logs["チケット"].str.extract(r"#(\d+)")
            period_logs["task_id"] = pd.to_numeric(period_logs["task_id_str"], errors="coerce").astype("Int64")
            
            # Group by task_id and sum hours
            hours_per_task = period_logs.groupby("task_id")["時間"].sum().sort_values(ascending=False)
            
            if not hours_per_task.empty:
                console.print(f"\n[green]✓ {title_period}に作業した主なタスク (時間順):[/green]")
                table_tasks = Table(show_header=True, header_style="bold cyan")
                table_tasks.add_column("#", width=6)
                table_tasks.add_column("題名", min_width=30)
                table_tasks.add_column("記録時間", width=10, justify="right")
                
                for task_id, hours in hours_per_task.head(5).items(): # Show top 5
                    # Ensure task_id is valid before lookup
                    if pd.isna(task_id):
                        continue
                    task_info = data_manager.get_task_by_id(int(task_id))
                    task_title = task_info.get("題名", "(不明なタスク)") if task_info else "(不明なタスク)"
                    table_tasks.add_row(str(task_id), task_title, f"{hours:.2f} h")
                console.print(table_tasks)
            else:
                 console.print(f"\n[yellow]- {title_period}に記録された特定のタスク作業はありませんでした。[/yellow]")
        else:
            console.print(f"\n[yellow]- {title_period}の作業ログはありません。[/yellow]")

        # 3. Progress on active tasks (e.g., tasks due soon or recently updated)
        console.print(f"\n[green]✓ アクティブなタスクの進捗:[/green]")
        # Define active tasks (e.g., TODO or 進行中 status, maybe due within next 2 weeks)
        active_tasks = data_manager.issues_df[
            (data_manager.issues_df["ステータス"].isin(["TODO", "進行中"])) &
            ( (data_manager.issues_df["期日"].isnull()) | (data_manager.issues_df["期日"] <= today + pd.Timedelta(days=14)) )
        ].sort_values(by="期日", ascending=True, na_position="last")

        if not active_tasks.empty:
            table_progress = Table(show_header=True, header_style="bold cyan")
            table_progress.add_column("#", width=6)
            table_progress.add_column("題名", min_width=30)
            table_progress.add_column("ステータス", width=10)
            table_progress.add_column("期日", width=12)
            table_progress.add_column("進捗%", width=6, justify="right")
            table_progress.add_column("残工数", width=8, justify="right")

            for index, task in active_tasks.head(10).iterrows(): # Show top 10 active
                due_date_str = task["期日"].strftime("%Y-%m-%d") if pd.notna(task["期日"]) else "-"
                progress_val = task.get("進捗率", 0)
                progress = f"{int(progress_val):>3d}%" if pd.notna(progress_val) else "-"
                remaining_hours_val = task.get("残工数", 0.0)
                remaining_hours = f"{remaining_hours_val:.2f}" if pd.notna(remaining_hours_val) else "-"
                table_progress.add_row(
                    str(task["#"]),
                    task["題名"],
                    task["ステータス"],
                    due_date_str,
                    progress,
                    remaining_hours
                )
            console.print(table_progress)
        else:
            console.print("[yellow]- アクティブなタスクはありません。[/yellow]")

    except Exception as e:
        console.print(f"[bold red]レポート生成中にエラーが発生しました: {e}[/bold red]")

# Allow running `python -m commands.report_cmd` for testing
if __name__ == "__main__":
    app()

