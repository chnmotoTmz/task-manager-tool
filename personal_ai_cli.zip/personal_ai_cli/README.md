# パーソナルAIアシスタント (CLI版)

## 概要

このCLIツールは、`issues.csv` (タスク管理) と `timelog.csv` (作業ログ) を使用して、日々のタスク管理と工数記録を支援するパーソナルAIアシスタントです。

## 機能

*   **タスク一覧表示 (`list show`)**: 登録されているタスクを一覧表示します。ステータスや優先度でのフィルタリング、期日や優先度でのソートが可能です。
*   **作業ログ記録 (`log add`)**: 指定したタスクIDに対して作業時間とコメントを記録します。記録された時間は自動的に関連するタスクの「作業時間」と「合計作業時間」に加算され、「進捗率」も更新されます。
*   **進捗レポート表示 (`report summary`)**: 指定した期間（週または月）の合計作業時間、作業した主なタスク、アクティブなタスクの進捗状況を表示します。
*   **計画提案 (`plan suggest`)**: 優先度と期日に基づいて、今後取り組むべきタスクを提案します。
*   **ステータス更新 (`status`)**: 指定したタスクIDのステータスを更新します。「完了」に更新すると、進捗率が100%になり、終了日が記録されます。

## セットアップ

1.  **Python環境**: Python 3.11 が必要です。
2.  **依存関係のインストール**: ツールを実行する前に、必要なライブラリをインストールしてください。
    ```bash
    cd /home/ubuntu/personal_ai_cli
    python3.11 -m pip install typer rich pandas
    ```
3.  **データファイル**: `/home/ubuntu/personal_ai_cli` ディレクトリに `issues.csv` と `timelog.csv` ファイルが存在することを確認してください。

## 使用方法

基本的なコマンドは以下の形式で実行します。

```bash
cd /home/ubuntu/personal_ai_cli
python3.11 main.py [COMMAND] [SUBCOMMAND] [ARGUMENTS] [OPTIONS]
```

**例:**

*   **ヘルプ表示**: `python3.11 main.py --help`
*   **TODOステータスのタスクを期日順に表示**: `python3.11 main.py list show --status TODO --sort 期日`
*   **優先度「高」のタスクを表示**: `python3.11 main.py list show --priority 高`
*   **タスクID 165 に 2.5 時間の作業ログを追加**: `python3.11 main.py log add 165 2.5 --comment "初期実装完了"`
*   **今週の作業サマリーを表示**: `python3.11 main.py report summary --period week`
*   **今後14日間の推奨タスクを表示**: `python3.11 main.py plan suggest --days 14`
*   **タスクID 163 のステータスを「進行中」に更新**: `python3.11 main.py status 163 進行中`
*   **タスクID 163 のステータスを「完了」に更新**: `python3.11 main.py status 163 完了`

## 注意点

*   CSVファイルはコマンド実行時に直接読み書きされます。操作を行うと元のCSVファイルが更新されますので、必要に応じてバックアップを取得してください。
*   現在の実装では、各コマンドモジュールが `DataManager` を個別にインスタンス化しています。これは理想的ではありませんが、プロトタイプとしては動作します。将来的な改善点として、単一のインスタンスを共有する仕組み（TyperのContextなど）の導入が考えられます。
*   自然言語による指示の解析機能はまだ実装されていません。コマンドと引数を正確に入力する必要があります。

## 今後の展望

*   自然言語処理機能の追加
*   データ保存先をCSVからデータベース (SQLiteなど) へ移行
*   Webアプリケーション化 (FlaskまたはFastAPIを使用)
*   より高度な計画提案ロジックの実装

